import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface BlogPost {
  id?: number;
  title: string;
  content: string;
  publication_date?: string;
  tag: string;
}

export interface BlogPostResponse {
  message?: string;
  blog_post?: BlogPost;
  deleted_blog_post?: BlogPost;
}


export interface Comment {
  id?: number;
  blog_post_id: number;
  name: string;
  comment_text: string;
  created_at?: string;
}

export interface CommentResponse {
  success: boolean;
  message: string;
  comment?: Comment;
}


@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'http://localhost:8000/'; // Adjust this to your Django API URL

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }

  // Get all blog posts
  getAllBlogPosts(): Observable<BlogPost[]> {
    return this.http.get<BlogPost[]>(`${this.baseUrl}/blog-posts/`);
  }

  // Get a specific blog post by ID
  getBlogPost(id: number): Observable<BlogPost> {
    return this.http.get<BlogPost>(`${this.baseUrl}/blog-posts/${id}/`);
  }

  // Create a new blog post
  createBlogPost(blogPost: BlogPost): Observable<BlogPostResponse> {
    return this.http.post<BlogPostResponse>(`${this.baseUrl}/blog-posts/`, blogPost, this.httpOptions);
  }

  // Update a blog post (PUT - full update)
  updateBlogPost(id: number, blogPost: BlogPost): Observable<BlogPostResponse> {
    return this.http.put<BlogPostResponse>(`${this.baseUrl}/blog-posts/${id}/`, blogPost, this.httpOptions);
  }

  // Partially update a blog post (PATCH)
  patchBlogPost(id: number, blogPost: Partial<BlogPost>): Observable<BlogPostResponse> {
    return this.http.patch<BlogPostResponse>(`${this.baseUrl}/blog-posts/${id}/`, blogPost, this.httpOptions);
  }

  // Delete a blog post
  deleteBlogPost(id: number): Observable<BlogPostResponse> {
    return this.http.delete<BlogPostResponse>(`${this.baseUrl}/blog-posts/${id}/`);
  }






  addComment(comment: {
    blog_post_id: number;
    name: string;
    comment_text: string;
  }): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/comments/`, comment);
  }

  getCommentsByBlogPost(blogPostId: number): Observable<Comment[]> {
    return this.http.get<Comment[]>(`${this.baseUrl}/comments/${blogPostId}`, this.httpOptions);
  }
}



