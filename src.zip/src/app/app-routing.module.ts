import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { StaffComponent } from './staff/staff.component';
import { BlogPostComponent } from './blog-post/blog-post.component';
const routes: Routes = [
 // 🔁 renamed path
  { path: 'staff', component: StaffComponent },
  { path: 'blog', component: BlogPostComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
