# In your schoolproject/urls.py
from django.contrib import admin
from django.urls import path, include
from django.http import JsonResponse

def debug_urls(request):
    from django.urls import get_resolver
    resolver = get_resolver()
    url_patterns = []
    for pattern in resolver.url_patterns:
        url_patterns.append(str(pattern))
    return HttpResponse("<br>".join(url_patterns))


urlpatterns = [
    path('debug-urls/', debug_urls), 
    path('admin/', admin.site.urls),
    #path('api/', include('studentapp.urls')), 
   path('', include('studentapp.urls')),
]