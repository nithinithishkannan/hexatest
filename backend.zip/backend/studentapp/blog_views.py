from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.utils import timezone
from .models.blogpost import BlogPost
from .models.comments import Comment   
from .models.tag import Tag

class BlogPostListAPIView(APIView):
    def get(self, request, id=None):
        if id:
            try:
                blog_post = BlogPost.objects.get(id=id)
                return Response({
                    "id": blog_post.id,
                    "title": blog_post.title,
                    "content": blog_post.content,
                    "publication_date": blog_post.publication_date,
                    "tag":blog_post.tag,
                }, status=status.HTTP_200_OK)
            except BlogPost.DoesNotExist:
                return Response({"error": "Blog post not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            blog_posts = BlogPost.objects.all().order_by('-publication_date')
            blog_post_list = []
            for blog_post in blog_posts:
                blog_post_list.append({
                    "id": blog_post.id,
                    "title": blog_post.title,
                    "content": blog_post.content,
                    "publication_date": blog_post.publication_date,
                    "tag":blog_post.tag,
                })
            return Response(blog_post_list, status=status.HTTP_200_OK)

    def post(self, request):
        title = request.data.get('title')
        content = request.data.get('content')
        publication_date = request.data.get('publication_date')
        tag=request.data.get('tag')
        if not title:
            return Response({"error": "Title is required"}, status=status.HTTP_400_BAD_REQUEST)
        if not content:
            return Response({"error": "Content is required"}, status=status.HTTP_400_BAD_REQUEST)        
        if not tag:
            return Response({"error": "Content is required"}, status=status.HTTP_400_BAD_REQUEST)
        if len(title) > 200:
            return Response({"error": "Title cannot exceed 200 characters"}, status=status.HTTP_400_BAD_REQUEST)
        try:
         
            blog_post_data = {
                'title': title,
                'content': content,
                'tag':tag,
            }

            if publication_date:
                try:
                    from django.utils.dateparse import parse_datetime
                    parsed_date = parse_datetime(publication_date)
                    if parsed_date:
                        blog_post_data['publication_date'] = parsed_date
                    else:
                        return Response({"error": "Invalid publication date format"}, status=status.HTTP_400_BAD_REQUEST)
                except Exception:
                    return Response({"error": "Invalid publication date format"}, status=status.HTTP_400_BAD_REQUEST)
            
            blog_post = BlogPost.objects.create(**blog_post_data)            
            return Response({
                "message": "Blog post created successfully",
                "blog_post": {
                    "id": blog_post.id,
                    "title": blog_post.title,
                    "content": blog_post.content,
                    "publication_date": blog_post.publication_date,
                    "tag": blog_post.tag,
                }
            }, status=status.HTTP_201_CREATED)           
        except Exception as e:
            return Response({"error": "Internal server error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def patch(self, request, id):
        try:
            blog_post = BlogPost.objects.get(id=id)
        except BlogPost.DoesNotExist:
            return Response({"error": "Blog post not found"}, status=status.HTTP_404_NOT_FOUND)        
        updated = False        
        if "title" in request.data:
            title = request.data["title"]
            if len(title) > 200:
                return Response({"error": "Title cannot exceed 200 characters"}, status=status.HTTP_400_BAD_REQUEST)
            blog_post.title = title
            updated = True            
        if "content" in request.data:
            blog_post.content = request.data["content"]
            updated = True           
        if "tag" in request.data:
            blog_post.tag = request.data["tag"]
            updated = True                            
        if "publication_date" in request.data:
            try:
                from django.utils.dateparse import parse_datetime
                parsed_date = parse_datetime(request.data["publication_date"])
                if parsed_date:
                    blog_post.publication_date = parsed_date
                    updated = True
                else:
                    return Response({"error": "Invalid publication date format"}, status=status.HTTP_400_BAD_REQUEST)
            except Exception:
                return Response({"error": "Invalid publication date format"}, status=status.HTTP_400_BAD_REQUEST)
        if not updated:
            return Response({"error": "No valid fields to update"}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            blog_post.save()
            return Response({
                "message": "Blog post updated successfully",
                "blog_post": {
                    "id": blog_post.id,
                    "title": blog_post.title,
                    "content": blog_post.content,
                    "publication_date": blog_post.publication_date,
                    "tag": blog_post.tag,
                }
            }, status=status.HTTP_200_OK)
        except Exception:
            return Response({"error": "Internal server error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def put(self, request, id):
        try:
            blog_post = BlogPost.objects.get(id=id)
        except BlogPost.DoesNotExist:
            return Response({"error": "Blog post not found"}, status=status.HTTP_404_NOT_FOUND)

        title = request.data.get('title')
        content = request.data.get('content')
        tag=request.data.get('tag')
        publication_date = request.data.get('publication_date')

        if not (title and content):
            return Response({"error": "Title and content are required"}, status=status.HTTP_400_BAD_REQUEST)
        if len(title) > 200:
            return Response({"error": "Title cannot exceed 200 characters"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            blog_post.title = title
            blog_post.content = content
            blog_post.tag = tag
            if publication_date:
                from django.utils.dateparse import parse_datetime
                parsed_date = parse_datetime(publication_date)
                if parsed_date:
                    blog_post.publication_date = parsed_date
                else:
                    return Response({"error": "Invalid publication date format"}, status=status.HTTP_400_BAD_REQUEST)            
            blog_post.save()
            return Response({
                "message": "Blog post updated successfully",
                "blog_post": {
                    "id": blog_post.id,
                    "title": blog_post.title,
                    "content": blog_post.content,
                    "publication_date": blog_post.publication_date,
                    "tag": blog_post.tag,
                }
            }, status=status.HTTP_200_OK)
        except Exception:
            return Response({"error": "Internal server error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request, id):
        try:
            blog_post = BlogPost.objects.get(id=id)
            blog_post_data = {
                "id": blog_post.id,
                "title": blog_post.title,
                "content": blog_post.content,
                "publication_date": blog_post.publication_date,
                "tag": blog_post.tag,
            }
            blog_post.delete()
            return Response({
                "message": "Blog post deleted successfully",
                "deleted_blog_post": blog_post_data
            }, status=status.HTTP_200_OK)
        except BlogPost.DoesNotExist:
            return Response({"error": "Blog post not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception:
            return Response({"error": "Internal server error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        
        

# add coments APIView

class CommentCreateAPIView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            blog_post_id = request.data.get('blog_post_id')
            name = request.data.get('name')
            comment_text = request.data.get('comment_text')

            if not blog_post_id or not name or not comment_text:
                return Response({'error': 'Missing required fields.'}, status=status.HTTP_400_BAD_REQUEST)

            try:
                blog_post = BlogPost.objects.get(pk=blog_post_id)
            except BlogPost.DoesNotExist:
                return Response({'error': 'Blog post not found.'}, status=status.HTTP_404_NOT_FOUND)

            comment = Comment.objects.create(
                blog_post=blog_post,
                name=name,
                comment_text=comment_text
            )

            return Response({
                'message': 'Comment created successfully.',
                'comment': {
                    'id': comment.id,
                    'blog_post': blog_post.id,
                    'name': comment.name,
                    'comment_text': comment.comment_text
                }
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
