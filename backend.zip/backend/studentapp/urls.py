from django.urls import path
from .blog_views import BlogPostListAPIView,CommentCreateAPIView



urlpatterns = [
    path('blog-posts/', BlogPostListAPIView.as_view(), name='blog-post-list'),
    path('blog-posts/<int:id>/', BlogPostListAPIView.as_view(), name='blog-post-detail'),
    path('comments/', CommentCreateAPIView.as_view(), name='create-comment'),
   
]







