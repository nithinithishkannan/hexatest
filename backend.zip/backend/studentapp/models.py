from django.db import models

#from .models.student import Student
from .models.blogpost import BlogPost
from .models.tag import Tag
from .models.comments import Comment
