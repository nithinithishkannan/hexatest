from django.db import models
from .blogpost import BlogPost
class Comment(models.Model):
    blog_post = models.ForeignKey(BlogPost, on_delete=models.CASCADE, related_name='comments')
    name = models.CharField(max_length=100)
    comment_text = models.TextField()
    
    
    class Meta:
        db_table = 'comments'
       