from django.db import models
from .blogpost import BlogPost
class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)
    blog_post = models.ForeignKey(BlogPost, on_delete=models.CASCADE, related_name='tags')

    
    class Meta:
        db_table = 'tags'
        