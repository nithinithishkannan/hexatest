# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from studentapp.models import Student

# class StudentListAPIView(APIView):
#     def get(self, request, id=None):
#         if id:
#             # Get specific student
#             try:
#                 student = Student.objects.get(id=id)
#                 return Response({
#                     "id": student.id,
#                     "name": student.name,
#                     "address": student.address,
#                     "fees": student.fees,
#                 }, status=status.HTTP_200_OK)
#             except Student.DoesNotExist:
#                 return Response({"error": "Student not found"}, status=status.HTTP_404_NOT_FOUND)
#         else:
#             # Get all students
#             students = Student.objects.all()
#             student_list = []
#             for student in students:
#                 student_list.append({
#                     "id": student.id,
#                     "name": student.name,
#                     "address": student.address,
#                     "fees": student.fees,
#                 })
#             return Response(student_list, status=status.HTTP_200_OK)

#     def post(self, request):
#         # Create new student
#         name = request.data.get('name')
#         address = request.data.get('address')
#         fees = request.data.get('fees')

#         # Validate required fields
#         if not name:
#             return Response({"error": "Name is required"}, status=status.HTTP_400_BAD_REQUEST)
#         if not address:
#             return Response({"error": "Address is required"}, status=status.HTTP_400_BAD_REQUEST)
#         if not fees:
#             return Response({"error": "Fees is required"}, status=status.HTTP_400_BAD_REQUEST)

#         # Validate fees is numeric
#         try:
#             fees = float(fees)
#             if fees < 0:
#                 return Response({"error": "Fees cannot be negative"}, status=status.HTTP_400_BAD_REQUEST)
#         except (ValueError, TypeError):
#             return Response({"error": "Fees must be a valid number"}, status=status.HTTP_400_BAD_REQUEST)

#         try:
#             # Create new student
#             student = Student.objects.create(
#                 name=name,
#                 address=address,
#                 fees=fees
#             )
            
#             return Response({
#                 "message": "Student created successfully",
#                 "student": {
#                     "id": student.id,
#                     "name": student.name,
#                     "address": student.address,
#                     "fees": student.fees,
#                 }
#             }, status=status.HTTP_201_CREATED)
            
#         except Exception as e:
#             return Response({"error": "Internal server error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
#     def patch(self, request, id):
#         try:
#             student = Student.objects.get(id=id)
#         except Student.DoesNotExist:
#             return Response({"error": "Student not found"}, status=status.HTTP_404_NOT_FOUND)
        
#         updated = False
#         if "name" in request.data:
#             student.name = request.data["name"]
#             updated = True
#         if "address" in request.data:
#             student.address = request.data["address"]
#             updated = True
#         if "fees" in request.data:
#             try:
#                 fees = float(request.data["fees"])
#                 if fees < 0:
#                     return Response({"error": "Fees cannot be negative"}, status=status.HTTP_400_BAD_REQUEST)
#                 student.fees = fees
#                 updated = True
#             except (ValueError, TypeError):
#                 return Response({"error": "Fees must be a valid number"}, status=status.HTTP_400_BAD_REQUEST)

#         if not updated:
#             return Response({"error": "No valid fields to update"}, status=status.HTTP_400_BAD_REQUEST)
        
#         try:
#             student.save()
#             return Response({
#                 "message": "Student updated successfully",
#                 "student": {
#                     "id": student.id,
#                     "name": student.name,
#                     "address": student.address,
#                     "fees": student.fees,
#                 }
#             }, status=status.HTTP_200_OK)
#         except Exception:
#             return Response({"error": "Internal server error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def put(self, request, id):
#         try:
#             student = Student.objects.get(id=id)
#         except Student.DoesNotExist:
#             return Response({"error": "Student not found"}, status=status.HTTP_404_NOT_FOUND)

#         name = request.data.get('name')
#         address = request.data.get('address')
#         fees = request.data.get('fees')

#         if not (name and address and fees):
#             return Response({"error": "All fields (name, address, fees) are required"}, status=status.HTTP_400_BAD_REQUEST)

#         # Validate fees
#         try:
#             fees = float(fees)
#             if fees < 0:
#                 return Response({"error": "Fees cannot be negative"}, status=status.HTTP_400_BAD_REQUEST)
#         except (ValueError, TypeError):
#             return Response({"error": "Fees must be a valid number"}, status=status.HTTP_400_BAD_REQUEST)

#         try:
#             student.name = name
#             student.address = address
#             student.fees = fees
#             student.save()
#             return Response({
#                 "message": "Student updated successfully",
#                 "student": {
#                     "id": student.id,
#                     "name": student.name,
#                     "address": student.address,
#                     "fees": student.fees,
#                 }
#             }, status=status.HTTP_200_OK)
#         except Exception:
#             return Response({"error": "Internal server error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def delete(self, request, id):
#         try:
#             student = Student.objects.get(id=id)
#             student_data = {
#                 "id": student.id,
#                 "name": student.name,
#                 "address": student.address,
#                 "fees": student.fees,
#             }
#             student.delete()
#             return Response({
#                 "message": "Student deleted successfully",
#                 "deleted_student": student_data
#             }, status=status.HTTP_200_OK)
#         except Student.DoesNotExist:
#             return Response({"error": "Student not found"}, status=status.HTTP_404_NOT_FOUND)
#         except Exception:
#             return Response({"error": "Internal server error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)